<?php

declare(strict_types = 1);

namespace hachkingtohach1\MinePos\task;

use hachkingtohach1\MinePos\MinePos;
use hachkingtohach1\MinePos\math\Math;
use pocketmine\scheduler\Task;
use pocketmine\level\Level;
use pocketmine\block\{Block, BlockIds};
use pocketmine\math\Vector3;
use pocketmine\Server;

class Bedrock extends Task {
	
	public function __construct(MinePos $plugin){
        $this->plugin = $plugin;		
	}	
	
	public function onRun(int $currentTick){      
		$time = microtime(true);		
		foreach($this->plugin->minepos->getAll() as $i => [$world, $chance1, $chance2, $blocks, $pos1, $pos2]) {			
		    $pos1 = Math::mathStr($pos1);
		    $pos2 = Math::mathStr($pos2);
			foreach($this->plugin->blockneedreplace->getAll() as $rpos => $name) {
                $posr = Math::mathStr($rpos);				
			    if(min($pos1->x, $pos2->x) <= $posr->x 
				    && max($pos1->x, $pos2->x) >= $posr->x 
			        && min($pos1->y, $pos2->y) <= $posr->y
			        && max($pos1->y, $pos2->y) >= $posr->y 
			        && min($pos1->z, $pos2->z) <= $posr->z
			        && max($pos1->z, $pos2->z) >= $posr->z) {
			    				        
					if($name == $world) {
						$level = $this->plugin->getServer()->getLevelByName($world);
						if(!$this->plugin->getServer()->isLevelGenerated($world)) {
                            return;
					    }
					    if(!$this->plugin->getServer()->isLevelLoaded($world)) {
                            $this->plugin->getServer()->loadLevel($world);
							return;
					    }
					    foreach(explode(',', $blocks) as $blockz) {						
				            switch (rand(1,5)) {
				                case $chance1: $block = 1; break;
				                case $chance2: $block = (int)$blockz; break;
                                default: $block =  1; break;				            
					        }
					        $this->plugin->setBlockNeed($level, $posr->x, $posr->y, $posr->z, $block, 0);
						}
					    $this->plugin->blockneedreplace->remove($rpos);					
					}
				}
			}
		}
		$time = microtime(true) - $time;	
	}				
}