<?php

declare(strict_types=1);

namespace hachkingtohach1\MinePos\event;

use hachkingtohach1\MinePos\{MinePos, math\Math}; 
use pocketmine\block\Block;
use pocketmine\Player;
use pocketmine\math\{Vector3, Vector2};
use pocketmine\utils\{Config,TextFormat};
use pocketmine\item\{Item,ItemFactory};
use pocketmine\network\mcpe\protocol\{MoveActorAbsolutePacket, LevelSoundEventPacket, LevelEventPacket, MovePlayerPacket}; 
use pocketmine\event\{block\BlockBreakEvent,block\BlockPlaceEvent,Listener}; 
use pocketmine\command\ConsoleCommandSender;

class EventListener implements Listener {

    public $plugin;

    public $total = [];	

    public function __construct(MinePos $plugin){
        $this->plugin = $plugin;
        $plugin->getServer()->getPluginManager()->registerEvents($this, $plugin);
    }	
	
	public function soundBlockBreak($player, $event) {
		$event->setXpDropAmount(1);
		$block = $event->getBlock();				
		
		$player->addXp($event->getXpDropAmount());		
		$player->getLevel()->broadcastLevelSoundEvent($player->asVector3(), LevelSoundEventPacket::SOUND_BREAK, mt_rand());
	}
	
	public function onBlockBreak(BlockBreakEvent $event) : void{	
		$block = $event->getBlock();
		$level = $block->getLevel();
		$player = $event->getPlayer();	
		$postion = Math::mathPostion($block);	
		if(isset($this->plugin->setup[$player->getName()])){
			switch($this->plugin->setup[$player->getName()]) {
				case 3:
				    $event->setCancelled(\true);	
					$player->sendMessage("[MinePos] Pos1 for MinePos is done!");
					unset($this->plugin->setup[$player->getName()]);
					$this->plugin->pos[$player->getName()] = $postion;
					$this->plugin->setup[$player->getName()] = 4;
                    $player->sendMessage("[MinePos] Now to break one block to set Pos2 for MinePos!");					
				break;
				case 4:
				    $event->setCancelled(\true);	
					$player->sendMessage("[MinePos] Pos2 for MinePos is done!");
					unset($this->plugin->setup[$player->getName()]);
					$data4 = $this->plugin->data4[$player->getName()];
					$this->plugin->saveMinePos($this->plugin->pos[$player->getName()],
						[
						    $this->plugin->data1[$player->getName()],
						    $this->plugin->data2[$player->getName()],
							$this->plugin->data3[$player->getName()],							
							"$data4",
							$this->plugin->pos[$player->getName()],
							$postion
						]
					);
					unset($this->plugin->pos[$player->getName()]);
					$player->sendMessage("[MinePos] New MinePos area was created!");
                    unset($this->plugin->datasetup[$player->getName()]);
				break;
			}
		}
        $vector3 = new Vector3($block->x, $block->y+1, $block->z);
		foreach($this->plugin->minepos->getAll() as $i => [$world, $chance1, $chance2, $blocks, $pos1, $pos2]) {	
		    if($pos1 == null && $pos2 == null) return;
			$pos1 = Math::mathStr($pos1);
		    $pos2 = Math::mathStr($pos2);
			if($level->getFolderName() == $world) {
                if(min($pos1->x, $pos2->x) <= $player->getX() 
				&& max($pos1->x, $pos2->x) >= $player->getX() 
			    && min($pos1->y, $pos2->y) <= $player->getY() 
			    && max($pos1->y, $pos2->y) >= $player->getY() 
			    && min($pos1->z, $pos2->z) <= $player->getZ() 
			    && max($pos1->z, $pos2->x) >= $player->getZ()) {			
			    $array_block = 
				[
				    1 => 4, 4 => 7,
					16 => 1, 14 => 1,
					15 => 1, 21 => 1,
					153 => 1, 73 => 1,
					74 => 1, 56 => 1,
					49 => 1
				];			
			    $array_item = 
				[
				    1 => [4, 0, 1], 4 => [4, 0, 1],
					16 => [263, 0, 1], 14 => [266, 0, 1],
				    15 => [265, 0, 1], 21 => [351, 4, 1],
					153 => [406, 0, 1], 73 => [331, 0, 1],
					74 => [331, 0, 1], 56 => [264, 0, 1],
					49 => [49, 0, 1]
				];
			    $array_block_need = 
				[
				    1, 4, 16, 14, 15, 21, 153, 73, 74, 56, 49
				];			
				    if($this->plugin->getConfig()->get("autoinv") == true){
						foreach($event->getDrops() as $drop) {
			                $event->getPlayer()->getInventory()->addItem($drop);
						}
						$event->setDrops([]);
					}
					else {
						$player->getLevel()->dropItem($vector3, Item::get($block->getId(), $block->getDamage(), 1));
					}
				    $this->soundBlockBreak($player, $event);
                    $level->setblock(new Vector3($block->x, $block->y, $block->z), Block::get($block->getId()));								
			        if(in_array(in_array($block->getId(), $array_block_need), [1, 4])){
				        $this->plugin->blockneedreplace->set(Math::mathPostion($block), $level->getName());
		                $this->plugin->blockneedreplace->save();
				    }
				}				
			}
		}
	}
}